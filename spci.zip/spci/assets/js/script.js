
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 50) {
                navbar.style.padding = '10px 0';
                navbar.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.1)';
            } else {
                navbar.style.padding = '15px 0';
                navbar.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
            }
        });

        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if(targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if(targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });

        // Set active nav link based on current page
        document.addEventListener('DOMContentLoaded', function() {
            const currentPage = window.location.pathname.split('/').pop();
            const navLinks = document.querySelectorAll('.nav-link');
            
            navLinks.forEach(link => {
                const linkPage = link.getAttribute('href');
                if (linkPage === currentPage) {
                    link.classList.add('active');
                } else {
                    link.classList.remove('active');
                }
            });
            
            // Set home as active if on index
            if (currentPage === 'index.html' || currentPage === '') {
                document.querySelector('.nav-link[href="index.html"]').classList.add('active');
            }
        });

                // Counter animation for stats
        document.addEventListener('DOMContentLoaded', function() {
            // Animate counters when in viewport
            const observerOptions = {
                threshold: 0.5
            };
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const statsElements = entry.target.querySelectorAll('.stats-number');
                        statsElements.forEach(element => {
                            const target = parseInt(element.textContent);
                            const suffix = element.textContent.replace(/[0-9]/g, '');
                            
                            // Reset to 0
                            let current = 0;
                            element.textContent = current + suffix;
                            
                            // Animate to target
                            const increment = target / 50;
                            const timer = setInterval(() => {
                                current += increment;
                                if (current >= target) {
                                    current = target;
                                    clearInterval(timer);
                                }
                                element.textContent = Math.floor(current) + suffix;
                            }, 30);
                        });
                        
                        // Stop observing after animation
                        observer.unobserve(entry.target);
                    }
                });
            }, observerOptions);
            
            // Observe the stats section
            const statsSection = document.querySelector('.why-choose-section');
            if (statsSection) {
                observer.observe(statsSection);
            }
            
            // Set current year in copyright if needed
            const yearElements = document.querySelectorAll('.current-year');
            yearElements.forEach(element => {
                element.textContent = new Date().getFullYear();
            });
            
            // Breadcrumb active page
            const currentPage = window.location.pathname.split('/').pop();
            const breadcrumbItems = document.querySelectorAll('.breadcrumb-item');
            breadcrumbItems.forEach(item => {
                const link = item.querySelector('a');
                if (link && link.getAttribute('href') === currentPage) {
                    item.classList.add('active');
                }
            });
        });
        // Add to your script.js file
        document.addEventListener('DOMContentLoaded', function() {
            const heroCarousel = document.getElementById('heroCarousel');
            if (heroCarousel) {
                const carousel = new bootstrap.Carousel(heroCarousel, {
                    interval: 3000, // Change slide every 5 seconds
                    pause: 'hover', // Pause on hover
                    wrap: true, // Continue looping
                    touch: true // Enable touch swiping on mobile
                });
            }
        });