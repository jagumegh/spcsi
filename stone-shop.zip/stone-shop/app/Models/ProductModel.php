<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table = 'products';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'category_id',
        'name',
        'slug',
        'short_description',
        'price_min',
        'price_max',
        'is_active'
    ];
}
