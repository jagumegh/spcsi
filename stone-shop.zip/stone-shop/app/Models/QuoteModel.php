<?php

namespace App\Models;

use CodeIgniter\Model;

class QuoteModel extends Model
{
    protected $table = 'quote_requests';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'mobile',
        'product_id',
        'source',
        'ip_address',
        'is_contacted'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField  = '';
}
