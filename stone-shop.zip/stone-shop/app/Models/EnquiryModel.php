<?php

namespace App\Models;

use CodeIgniter\Model;

class EnquiryModel extends Model
{
    protected $table = 'enquiries';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'name',
        'phone',
        'email',
        'subject',
        'product_interest',
        'message',
        'newsletter',
        'ip_address'
    ];
}
