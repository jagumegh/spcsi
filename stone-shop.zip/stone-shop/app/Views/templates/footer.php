<footer class="site-footer">
    <div class="container">
        <div class="row gy-4">
            <!-- Company Info -->
            <div class="col-lg-5 col-md-12">
                <div class="footer-logo">Shri Pramhans Stone</div>
                <p class="footer-desc">
                    Manufacturer of high-quality sandstone, marble & decorative stone products in Dausa,
                    Rajasthan. We specialize in precision stone cutting, shaping, and finishing.
                    <br>
                    Specializing in marble carving, sandstone wall murals,
                    stone jali designs and decorative stone products.
                </p>
                <!-- Add GST/Registration if available -->
                <p class="gst-info"><small>GST No: [08PQHPS0363E1ZG]</small></p>
            </div>

            <!-- Quick Links -->
            <div class="col-lg-3 col-md-6">
                <div class="footer-links">
                    <h5>Quick Links</h5>
                    <ul class="footer-menu">
                        <li><a href="/">Home</a></li>
                        <li><a href="/about">About Us</a></li>
                        <li><a href="/products">Products</a></li>
                        <li><a href="/projects">Projects</a></li>
                        <li><a href="/contact">Contact</a></li>
                    </ul>
                </div>
            </div>

            <!-- Contact Info -->
            <div class="col-lg-4 col-md-6">
                <div class="footer-links">
                    <h5>Contact Info</h5>
                    <div class="contact-info">
                        <p><i class="fas fa-map-marker-alt"></i> Dausa, Rajasthan, India</p>
                        <p><i class="fas fa-phone-alt"></i> <a style=" text-decoration: none;"
                                href="tel:08048606757">08048606757</a></p>
                        <p><i class="fab fa-whatsapp"></i> <a href="https://wa.me/918048606757"
                                target="_blank">WhatsApp</a></p>
                        <p><i class="fas fa-user"></i> Chetan Kumar Saini</p>
                        <p><i class="fas fa-envelope"></i> <a
                                href="mailto:info@shripramhansstones.com">info@shripramhansstones.com</a></p>
                    </div>
                    <div class="social-icons mt-3">
                        <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                        <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-bottom mt-4 pt-4 border-top">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="copyright">
                        © 2024 Shri Pramhans Cutting Stone Industries. All Rights Reserved.
                    </div>
                </div>
                <div class="col-md-6 text-md-end">
                    <div class="footer-policies">
                        <a href="/privacy-policy" class="me-3">Privacy Policy</a>
                        <a href="/terms-conditions">Terms & Conditions</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Back to Top Button -->

</body>
<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url('assets/js/script.js') ?>"></script>
<!-- Add FontAwesome if not already included -->
<script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>

</html>