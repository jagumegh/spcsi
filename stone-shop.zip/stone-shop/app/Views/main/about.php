<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Shri Pramhans Cutting Stone Industries | Stone Manufacturer in Rajasthan</title>
    
    <link rel="shortcut icon" href="<?= base_url('assets/images/favicon.png') ?>" type="image/x-icon">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Roboto+Slab:wght@300;400;500;600&display=swap"
        rel="stylesheet">

    <meta name="description"
        content="Know more about Shri Pramhans Cutting Stone Industries, a trusted stone manufacturer in Dausa, Rajasthan. Learn about our mission, expertise, quality standards and craftsmanship.">

    <meta name="keywords"
        content="stone manufacturer in rajasthan, sandstone supplier india, marble carving manufacturer, stone wall murals, stone jali design, dausa stone industry">
    <link rel="canonical" href="<?= base_url('about') ?>">

    <meta name="author" content="Shri Pramhans Cutting Stone Industries">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="About Shri Pramhans Cutting Stone Industries">
    <meta property="og:description"
        content="Learn about our stone manufacturing expertise, mission, vision and craftsmanship in Rajasthan.">
    <meta property="og:url" content="<?= base_url('about') ?>">
    <meta property="og:type" content="website">
    <meta property="og:image" content="<?= base_url('assets/images/logo.png') ?>">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/css/styles.css') ?>">

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "ManufacturingBusiness",
      "name": "Shri Pramhans Cutting Stone Industries",
      "founder": "Chetan Kumar Saini",
      "foundingDate": "2024",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Dausa",
        "addressRegion": "Rajasthan",
        "addressCountry": "IN"
      },
      "telephone": "+91-8048606757",
      "url": "<?= base_url() ?>"
    }
    </script>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [{
        "@type": "Question",
        "name": "Where is Shri Pramhans Cutting Stone Industries located?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Shri Pramhans Cutting Stone Industries is located in Dausa, Rajasthan, India."
        }
      }]
    }
    </script>
</head>

<body>
    <!-- Header Section -->
    <?= $this->include('templates/header'); ?>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <h1>About Shri Pramhans Cutting Stone Industries</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?= site_url('/') ?>">Home</a></li>
                    <li class="breadcrumb-item active">About Us</li>
                </ol>
            </nav>
        </div>
    </section>

    <!-- About Intro -->
    <section class="about-intro">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-5 mb-lg-0">
                    <div class="section-title">
                        <h2>Leading Stone Manufacturer in Dausa, Rajasthan</h2>
                    </div>
                    <p>Established in 2024, Shri Pramhans Cutting Stone Industries is a leading manufacturer and
                        supplier of premium natural stone products, based in Dausa, Rajasthan. We specialize in stone
                        cutting, shaping, carving, and finishing, delivering products that combine natural beauty,
                        strength, and long-lasting quality.</p>
                    <p>With a strong focus on craftsmanship and precision, we offer a wide range of sandstone items,
                        marble products, white stone, red stone, black stone products, and customized stone solutions.
                        Our products are widely used in residential projects, commercial buildings, temples, hotels,
                        landscaping, and artistic installations.</p>
                    <div class="mt-4">
                        <a href="<?= site_url('products') ?>" class="btn btn-primary me-3">View Our Products</a>
                        <a href="<?= site_url('contact') ?>" class="btn btn-outline-primary">Contact Us</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-image">
                        <img src="<?= base_url('assets/images/logo.png') ?>" loading="lazy"
                            alt="Stone manufacturer in Dausa Rajasthan - Shri Pramhans Cutting Stone Industries">
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Mission & Vision -->
    <section class="mission-vision-section">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6">
                    <div class="mission-box">
                        <div class="mission-icon">
                            <i class="fas fa-bullseye"></i>
                        </div>
                        <h3>Our Mission</h3>
                        <p>To deliver high-quality stone products that meet customer expectations in design, durability,
                            and timely delivery, while maintaining fair pricing and long-term relationships.</p>
                        <ul class="mt-4">
                            <li class="mb-2">Exceptional quality in every product</li>
                            <li class="mb-2">Customer satisfaction as top priority</li>
                            <li class="mb-2">Innovative design solutions</li>
                            <li>Reliable and timely delivery</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="vision-box">
                        <div class="vision-icon">
                            <i class="fas fa-eye"></i>
                        </div>
                        <h3>Our Vision</h3>
                        <p>To become a trusted and recognized name in the stone industry by continuously improving
                            quality, adopting modern techniques, and offering innovative stone solutions.</p>
                        <ul class="mt-4">
                            <li class="mb-2">Industry leadership in stone craftsmanship</li>
                            <li class="mb-2">Sustainable business practices</li>
                            <li class="mb-2">Continuous innovation and improvement</li>
                            <li>Expanding global presence</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Why Choose Us -->
    <section class="why-choose-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-5 mb-lg-0">
                    <div class="section-title">
                        <h2>Why Choose Us</h2>
                    </div>
                    <p class="mb-4">We combine traditional craftsmanship with modern technology to deliver exceptional
                        stone products that stand the test of time.</p>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="feature-check">
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <h5>Premium Quality</h5>
                                    <p>Carefully selected raw materials</p>
                                </div>
                            </div>
                            <div class="feature-check">
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <h5>Modern Machinery</h5>
                                    <p>Advanced cutting & finishing equipment</p>
                                </div>
                            </div>
                            <div class="feature-check">
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <h5>Skilled Workforce</h5>
                                    <p>Experienced craftsmen and technicians</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="feature-check">
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <h5>Timely Delivery</h5>
                                    <p>Reliable and prompt service</p>
                                </div>
                            </div>
                            <div class="feature-check">
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <h5>Wide Range</h5>
                                    <p>Multiple stone types and finishes</p>
                                </div>
                            </div>
                            <div class="feature-check">
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <h5>Customer Focus</h5>
                                    <p>Personalized support and fair pricing</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="stats-box">
                                <div class="stats-number">110+</div>
                                <h5>Projects Completed</h5>
                                <p>Residential, commercial, and institutional</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="stats-box">
                                <div class="stats-number">25+</div>
                                <h5>Skilled Craftsmen</h5>
                                <p>Experienced artisans and technicians</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="stats-box">
                                <div class="stats-number">50+</div>
                                <h5>Product Types</h5>
                                <p>Variety of stone designs and finishes</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="stats-box">
                                <div class="stats-number">100%</div>
                                <h5>Client Satisfaction</h5>
                                <p>Committed to quality and service</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<!-- Company Profile with CEO Side-by-Side -->
<section class="company-profile-section">
    <div class="container">
        <div class="section-title text-center">
            <h2>Company Profile</h2>
            <p class="lead mt-3">Official details and business information</p>
        </div>
        
        <div class="row">
            <!-- CEO Profile Card (Left) -->
            <div class="col-lg-4">
                <div class="ceo-profile-card">
                    <div class="ceo-img">
                        <img src="<?= base_url('assets/images/ceo.jpg') ?>" 
                             alt="Chetan Kumar Saini - CEO & Founder"
                             onerror="this.src='<?= base_url('assets/images/logo.png') ?>'">
                    </div>
                    <div class="ceo-info">
                        <h4>Chetan Kumar Saini</h4>
                        <p class="ceo-position">CEO & Founder</p>
                        
                        <div class="ceo-contact">
                            <div class="contact-item">
                                <i class="fas fa-envelope"></i>
                                <span>Email: info@company.com</span>
                            </div>
                            <div class="contact-item">
                                <i class="fas fa-phone"></i>
                                <span>Phone: +91 8048606757</span>
                            </div>
                            <div class="contact-item">
                                <i class="fas fa-map-marker-alt"></i>
                                <span>Dausa, Rajasthan</span>
                            </div>
                        </div>
                        
                        <p class="ceo-bio">
                            With extensive experience in stone industry, leading the company with vision and dedication. 
                            Committed to quality and customer satisfaction in every project.
                        </p>
                        
                        <div class="ceo-badges">
                            <span class="badge">Industry Expert</span>
                            <span class="badge">Quality Focus</span>
                            <span class="badge">Customer First</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Company Details (Right) -->
            <div class="col-lg-8">
                <div class="profile-card">
                    <div class="row">
                        <!-- Left Column -->
                        <div class="col-md-6">
                            <div class="profile-item">
                                <div class="profile-icon">
                                    <i class="fas fa-building"></i>
                                </div>
                                <div>
                                    <div class="profile-label">Nature of Business</div>
                                    <div class="profile-value">Manufacturer</div>
                                </div>
                            </div>
                            <div class="profile-item">
                                <div class="profile-icon">
                                    <i class="fas fa-industry"></i>
                                </div>
                                <div>
                                    <div class="profile-label">Additional Business</div>
                                    <div class="profile-value">Factory / Wholesale / Retail</div>
                                </div>
                            </div>
                            <div class="profile-item">
                                <div class="profile-icon">
                                    <i class="fas fa-user-tie"></i>
                                </div>
                                <div>
                                    <div class="profile-label">Company CEO</div>
                                    <div class="profile-value">Chetan Kumar Saini</div>
                                </div>
                            </div>
                            <div class="profile-item">
                                <div class="profile-icon">
                                    <i class="fas fa-users"></i>
                                </div>
                                <div>
                                    <div class="profile-label">Total Employees</div>
                                    <div class="profile-value">11–25 People</div>
                                </div>
                            </div>
                        </div>
                        <!-- Right Column -->
                        <div class="col-md-6">
                            <div class="profile-item">
                                <div class="profile-icon">
                                    <i class="fas fa-file-invoice-dollar"></i>
                                </div>
                                <div>
                                    <div class="profile-label">GST No.</div>
                                    <div class="profile-value">08PQHPS0363E1ZG</div>
                                </div>
                            </div>
                            <div class="profile-item">
                                <div class="profile-icon">
                                    <i class="fas fa-id-card"></i>
                                </div>
                                <div>
                                    <div class="profile-label">UDYAM No.</div>
                                    <div class="profile-value">UDYAM-RJ-12-0039185</div>
                                </div>
                            </div>
                            <div class="profile-item">
                                <div class="profile-icon">
                                    <i class="fas fa-calendar-alt"></i>
                                </div>
                                <div>
                                    <div class="profile-label">Year of Establishment</div>
                                    <div class="profile-value">2024</div>
                                </div>
                            </div>
                            <div class="profile-item">
                                <div class="profile-icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div>
                                    <div class="profile-label">Location</div>
                                    <div class="profile-value">Dausa, Rajasthan, India</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Company Certifications -->
                    <div class="company-certifications mt-4">
                        <h5 class="cert-title mb-4">Company Certifications & Registrations</h5>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <div class="cert-item">
                                    <div class="cert-icon">
                                        <i class="fas fa-certificate"></i>
                                    </div>
                                    <div class="cert-details">
                                        <h6>GST Registered</h6>
                                        <small>Tax Compliance</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="cert-item">
                                    <div class="cert-icon">
                                        <i class="fas fa-award"></i>
                                    </div>
                                    <div class="cert-details">
                                        <h6>MSME Registered</h6>
                                        <small>Govt. Recognized</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="cert-item">
                                    <div class="cert-icon">
                                        <i class="fas fa-shield-alt"></i>
                                    </div>
                                    <div class="cert-details">
                                        <h6>Quality Certified</h6>
                                        <small>Premium Standards</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    <!-- Our Expertise -->
    <section class="expertise-section">
        <div class="container">
            <div class="section-title text-center">
                <h2>Our Expertise</h2>
                <p class="lead mt-3">We bring together modern technology and traditional craftsmanship</p>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-4">
                    <div class="expertise-item">
                        <div class="expertise-icon">
                            <i class="fas fa-cut"></i>
                        </div>
                        <h4>Precision Cutting</h4>
                        <p>Utilizing state-of-the-art machinery for accurate stone cutting and shaping with millimeter
                            precision.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="expertise-item">
                        <div class="expertise-icon">
                            <i class="fas fa-hammer"></i>
                        </div>
                        <h4>Expert Craftsmanship</h4>
                        <p>Skilled artisans with years of experience in stone carving and intricate detailing work.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="expertise-item">
                        <div class="expertise-icon">
                            <i class="fas fa-gem"></i>
                        </div>
                        <h4>Quality Finishing</h4>
                        <p>Advanced polishing and finishing techniques to enhance the natural beauty of stone.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="expertise-item">
                        <div class="expertise-icon">
                            <i class="fas fa-th-large"></i>
                        </div>
                        <h4>Wide Product Range</h4>
                        <p>From wall panels and murals to jali, arches, and sculptures - diverse stone solutions.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="expertise-item">
                        <div class="expertise-icon">
                            <i class="fas fa-user-cog"></i>
                        </div>
                        <h4>Custom Solutions</h4>
                        <p>Tailored stone products designed to meet specific client requirements and architectural
                            needs.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="expertise-item">
                        <div class="expertise-icon">
                            <i class="fas fa-shipping-fast"></i>
                        </div>
                        <h4>Timely Delivery</h4>
                        <p>Efficient logistics and supply chain management ensuring prompt delivery across India.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>



<style>
    /* CEO Profile Card */

</style>

    <!-- Footer -->
    <?= $this->include('templates/footer'); ?>