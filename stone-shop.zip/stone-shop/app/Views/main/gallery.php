<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery | Shri Pramhans Cutting Stone Industries | Stone Products Portfolio</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Roboto+Slab:wght@300;400;500;600&display=swap"
        rel="stylesheet">

    <!-- SEO Meta Tags -->
    <meta name="description"
        content="Explore our stone products gallery featuring marble carvings, sandstone designs, stone jali, wall murals, and custom stone work from Dausa, Rajasthan.">
    <meta name="keywords"
        content="stone products gallery, marble carving images, sandstone designs photos, stone jali designs, stone wall murals, rajasthan stone work, stone manufacturer portfolio">
    <link rel="canonical" href="https://shripramhansstones.com/gallery.html">
    <meta name="author" content="Shri Pramhans Cutting Stone Industries">
    <meta name="robots" content="index, follow">

    <!-- Open Graph -->
    <meta property="og:title" content="Gallery | Shri Pramhans Cutting Stone Industries">
    <meta property="og:description"
        content="Explore our stone products gallery featuring marble carvings, sandstone designs, and custom stone work.">
    <meta property="og:url" content="https://shripramhansstones.com/gallery.html">
    <meta property="og:type" content="website">
    <meta property="og:image" content="https://shripramhansstones.com/assets/images/logo.png">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/styles.css">

    <!-- Schema Markup -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "ImageGallery",
      "name": "Stone Products Gallery - Shri Pramhans Cutting Stone Industries",
      "description": "Gallery of stone products including marble carvings, sandstone designs, stone jali, and custom stone work",
      "url": "https://shripramhansstones.com/gallery.html",
      "image": [
        "https://shripramhansstones.com/assets/gallery/sandstone-1.jpg",
        "https://shripramhansstones.com/assets/gallery/marble-1.jpg",
        "https://shripramhansstones.com/assets/gallery/jali-1.jpg"
      ]
    }
    </script>
</head>

<body>
    <!-- Header Section -->
    <?= view('templates/header') ?>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <h1>Our Stone Products Gallery</h1>
            <p class="lead mt-2">Explore our collection of exquisite stone work and craftsmanship</p>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item active">Gallery</li>
                </ol>
            </nav>
        </div>
    </section>

    <!-- Gallery Filter -->
    <section class="gallery-filter">
        <div class="container">
            <div class="filter-buttons">
                <button class="filter-btn active" data-filter="all">All Works</button>
                <button class="filter-btn" data-filter="sandstone">Sandstone</button>
                <button class="filter-btn" data-filter="marble">Marble</button>
                <button class="filter-btn" data-filter="jali">Stone Jali</button>
                <button class="filter-btn" data-filter="carving">Carving</button>
                <button class="filter-btn" data-filter="wall-murals">Wall Murals</button>
                <button class="filter-btn" data-filter="custom">Custom Work</button>
            </div>
        </div>
    </section>

    <!-- Gallery Grid -->
    <section class="gallery-grid">
        <div class="container">
            <div class="row g-4" id="galleryContainer">

            <?php foreach ($gallery as $item): ?>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 gallery-item <?= esc($item['css_class']) ?>"
                    style="animation-delay: <?= esc($item['animation_delay']) ?>;">

                    <div class="gallery-card">
                        <img
                            src="<?= base_url('assets/images/gallery/' . esc($item['image'])) ?>"
                            class="img-fluid"
                            alt="<?= esc($item['title']) ?>"
                            loading="lazy">

                        <div class="gallery-overlay">
                            <div class="gallery-info">
                                <span class="gallery-category"><?= esc(ucfirst($item['css_class'])) ?></span>
                                <h4><?= esc($item['title']) ?></h4>
                                <p><?= esc($item['short_description']) ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>

                <!-- Lightbox -->
                <div class="lightbox" id="lightbox">
                    <span class="lightbox-close" id="lightboxClose">&times;</span>
                    <div class="lightbox-content">
                        <button class="lightbox-nav prev" id="lightboxPrev">❮</button>
                        <img id="lightboxImage" src="" alt="Gallery Image">
                        <button class="lightbox-nav next" id="lightboxNext">❯</button>
                    </div>
                    <div class="lightbox-info" id="lightboxInfo">
                        <h4 id="lightboxTitle"></h4>
                        <p id="lightboxDescription"></p>
                        <div class="lightbox-actions">
                            <button class="btn-share" id="shareBtn">
                                <i class="fas fa-share-alt"></i> Share
                            </button>
                            <button class="btn-enquire" id="enquireBtn">
                                <i class="fas fa-question-circle"></i> Enquire
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Load More Button -->
                <div class="text-center mt-5">
                    <button class="btn btn-primary px-5 py-3" id="loadMoreBtn">
                        <i class="fas fa-plus-circle me-2"></i> Load More Works
                    </button>
                </div>
            </div>
    </section>

    <!-- Project Categories -->
    <section class="category-section">
        <div class="container">
            <div class="section-title text-center">
                <h2>Our Stone Product Categories</h2>
                <p class="lead mt-3">Explore different types of stone work we specialize in</p>
            </div>

            <div class="row g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="category-card">
                        <div class="category-image">
                            <img src="https://images.unsplash.com/photo-1541140532154-b024d705b90a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                                alt="Sandstone Products" loading="lazy">
                        </div>
                        <div class="category-info">
                            <h4>Sandstone</h4>
                            <p>Natural sandstone products with beautiful textures and colors</p>
                            <div class="category-count">25+ Designs</div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3">
                    <div class="category-card">
                        <div class="category-image">
                            <img src="https://images.unsplash.com/photo-1598443773922-3c90d8d07490?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                                alt="Marble Products" loading="lazy">
                        </div>
                        <div class="category-info">
                            <h4>Marble</h4>
                            <p>Premium marble carvings and installations</p>
                            <div class="category-count">20+ Designs</div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3">
                    <div class="category-card">
                        <div class="category-image">
                            <img src="https://images.unsplash.com/photo-1581338834647-b0fb407c6e59?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                                alt="Stone Jali Work" loading="lazy">
                        </div>
                        <div class="category-info">
                            <h4>Stone Jali</h4>
                            <p>Intricate lattice stone work for windows and partitions</p>
                            <div class="category-count">30+ Designs</div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3">
                    <div class="category-card">
                        <div class="category-image">
                            <img src="https://images.unsplash.com/photo-1503387762-592deb58ef4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                                alt="Stone Carvings" loading="lazy">
                        </div>
                        <div class="category-info">
                            <h4>Stone Carvings</h4>
                            <p>Hand-carved stone sculptures and decorative pieces</p>
                            <div class="category-count">40+ Designs</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="testimonial-section">
        <div class="container">
            <div class="section-title text-center">
                <h2>Client Testimonials</h2>
                <p class="lead mt-3">What our clients say about our work</p>
            </div>

            <div class="testimonial-slider">
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        The sandstone jali work for our temple project was executed with precision and craftsmanship.
                        The attention to detail is remarkable.
                    </div>
                    <div class="testimonial-author">
                        <div class="author-img">
                            <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
                                alt="Client" loading="lazy">
                        </div>
                        <div class="author-info">
                            <h5>Rajesh Sharma</h5>
                            <p>Temple Trust, Jaipur</p>
                        </div>
                    </div>
                </div>

                <div class="testimonial-card">
                    <div class="testimonial-text">
                        The marble carvings for our hotel lobby were delivered on time and exceeded our expectations.
                        The quality is exceptional.
                    </div>
                    <div class="testimonial-author">
                        <div class="author-img">
                            <img src="https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
                                alt="Client" loading="lazy">
                        </div>
                        <div class="author-info">
                            <h5>Priya Verma</h5>
                            <p>Hotel Grand, Udaipur</p>
                        </div>
                    </div>
                </div>

                <div class="testimonial-card">
                    <div class="testimonial-text">
                        Custom stone work for our resort was perfectly executed. The team understood our vision and
                        delivered beyond expectations.
                    </div>
                    <div class="testimonial-author">
                        <div class="author-img">
                            <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
                                alt="Client" loading="lazy">
                        </div>
                        <div class="author-info">
                            <h5>Amit Patel</h5>
                            <p>Resort Owner, Goa</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-content">
                <h2>Looking for Custom Stone Solutions?</h2>
                <p>Contact us with your requirements and we'll create unique stone products tailored to your needs.</p>

                <div class="cta-buttons">
                    <a href="contact.html" class="btn btn-outline-light">Contact Us</a>
                    <a href="quote.html" class="btn btn-primary">Get Free Quote</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
     <<?= view('templates/footer') ?>