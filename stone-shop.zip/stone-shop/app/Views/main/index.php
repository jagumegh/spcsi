<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stone Manufacturer in Rajasthan | Marble & Sandstone Supplier – Shri Pramhans</title>
    <!-- Use helper for base URL -->
    <link rel="shortcut icon" href="<?= base_url('assets/images/favicon.png') ?>" type="image/x-icon">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Roboto+Slab:wght@300;400;500;600&display=swap"
        rel="stylesheet">

    <meta name="description"
        content="Shri Pramhans Cutting Stone Industries is a leading stone manufacturer in Dausa, Rajasthan. We supply marble, sandstone, wall murals, jali & decorative stone products across India.">

    <meta name="keywords"
        content="stone manufacturer in rajasthan, sandstone supplier india, marble carving manufacturer, stone wall murals, stone jali design, dausa stone industry">

    <meta name="author" content="Shri Pramhans Cutting Stone Industries">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="Stone Manufacturer in Rajasthan – Shri Pramhans">
    <meta property="og:description"
        content="Manufacturer of marble, sandstone, wall murals & decorative stone products in Rajasthan.">
    <meta property="og:image" content="<?= base_url('assets/images/logo.png') ?>">
    <meta property="og:url" content="<?= base_url() ?>">
    <meta property="og:type" content="website">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/css/styles.css') ?>">

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Manufacturer",
      "name": "Shri Pramhans Cutting Stone Industries",
      "image": "<?= base_url('assets/images/logo.png') ?>",
      "telephone": "+91-8048606757",
      "email": "info@shripramhansstones.com",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Dausa",
        "addressRegion": "Rajasthan",
        "addressCountry": "IN"
      },
      "url": "<?= base_url() ?>",
      "sameAs": [
        "https://www.facebook.com/",
        "https://www.instagram.com/",
        "https://www.linkedin.com/"
      ]
    }
    </script>
</head>

<body>
    <!-- Header Section -->
    <?= $this->include('templates/header') ?>

    <!-- Hero Slider Section -->
    <section class="hero-slider">
        <div id="heroCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="2500">
            <!-- Indicators -->
            <div class="carousel-indicators">
                <?php if (isset($sliders) && !empty($sliders)): ?>
                <?php foreach ($sliders as $key => $slide): ?>
                <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="<?= $key ?>"
                    class="<?= $key === 0 ? 'active' : '' ?>" aria-current="<?= $key === 0 ? 'true' : 'false' ?>">
                </button>
                <?php endforeach; ?>
                <?php else: ?>
                <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="0" class="active"
                    aria-current="true"></button>
                <?php endif; ?>
            </div>

            <!-- Slides -->
            <div class="carousel-inner">
                <?php if (isset($sliders) && !empty($sliders)): ?>
                <?php foreach ($sliders as $key => $slide): ?>
                <div class="carousel-item <?= $key === 0 ? 'active' : '' ?>">
                    <div class="hero-slide" style="background-image:
                                linear-gradient(rgba(0,0,0,.5), rgba(0,0,0,.5)),
                                url('<?= base_url('assets/images/slider/' . $slide['img']) ?>');">
                        <div class="container">
                            <div class="product-info">
                                <h2>
                                    <?= esc($slide['name']) ?>
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <!-- Default slide if no sliders are provided -->
                <div class="carousel-item active">
                    <div class="hero-slide" style="background-image:
                            linear-gradient(rgba(0,0,0,.5), rgba(0,0,0,.5)),
                            url('<?= base_url('assets/images/slider/default-slide.jpg') ?>');">
                        <div class="container">
                            <div class="product-info">
                                <h2>Welcome to Shri Pramhans</h2>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Controls -->
            <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
            </button>
        </div>
    </section>
            <?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
        <strong>✔</strong> <?= session()->getFlashdata('success') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>
    <!-- Featured Products Section -->
    <section class="section-padding">
        <div class="container">
            <div class="section-title">
                <h2>Our Featured Stone Products</h2>
                <p class="lead">Premium Marble, Sandstone & Decorative Stone Creations</p>
                <p>Discover our finest collection of hand-crafted wall panels, murals, jali, and sculptures made from
                    high-quality natural stone.</p>
            </div>

            <!-- Product Grid -->
            <div class="row g-4">
                <?php foreach ($products as $product): ?>
                <div class="col-6 col-sm-4 col-md-4 col-lg-3 mb-4 product-item">

                    <div class="product-card">

                        <div class="product-image">
                            <img src="<?= !empty($product['image_url'])
                            ? base_url('assets/images/' . esc($product['image_url']))
                            : base_url('assets/images/pro2.jpg') ?>" alt="<?= esc($product['name']) ?>">
                        </div>

                        <div class="product-info">

                            <div class="product-category">
                                <?= esc(strtoupper($product['category_name'])) ?>
                            </div>

                            <h3 class="product-title">
                                <a href="<?= site_url('product/' . esc($product['slug'])) ?>">
                                    <?= esc($product['name']) ?>
                                </a>
                            </h3>

                            <p class="product-description">
                                <?= esc($product['short_description']) ?>
                            </p>

                            <div class="product-price">
                                ₹
                                <?= esc($product['price']) ?>
                            </div>

                            <div class="product-meta">
                                <div class="product-actions d-flex gap-2">

                                    <a href="<?= site_url('product/' . esc($product['slug'])) ?>"
                                        class="btn btn-sm btn-view">
                                        View Details
                                    </a>

                                    <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#quoteModal" data-product-id="<?= esc($product['id']) ?>">
                                        Send Enquiry
                                    </a>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>




            <!-- Action Buttons (separate row) -->
            <div class="text-center mt-5">
                <div class="row justify-content-center g-3">
                    <div class="col-12 col-md-4">
                        <a href="<?= site_url('products') ?>" class="btn btn-primary btn-lg w-100">
                            <i class="fas fa-th-large me-2"></i>View All Products
                        </a>
                    </div>
                    <div class="col-12 col-md-4">
                        <a href="#" class="btn btn-outline-primary btn-lg w-100" data-bs-toggle="modal"
                            data-bs-target="#quoteModal">
                            <i class="fas fa-file-invoice me-2"></i>Request a Quote
                        </a>
                    </div>
                    <div class="col-12 col-md-4">
                        <a href="https://wa.me/918048606757" target="_blank" class="btn btn-success btn-lg w-100">
                            <i class="fab fa-whatsapp me-2"></i>WhatsApp Now
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <!-- Intro Section -->
    <section class="intro-section section-padding">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-5 mb-lg-0">
                    <div class="section-title text-start">
                        <h2>Welcome to Shri Pramhans Cutting Stone Industries</h2>
                    </div>
                    <p>Founded in 2024, Shri Pramhans Cutting Stone Industries is a trusted stone manufacturer and
                        supplier based in Dausa, Rajasthan. We offer a wide range of sandstone, marble, white stone, red
                        stone, and black stone products, crafted with precision and delivered on time.</p>
                    <p>With modern machinery and skilled craftsmen, we transform natural stone into beautiful, durable,
                        and functional products for homes, commercial spaces, temples, and architectural projects.</p>
                    <div class="mt-4">
                        <a href="<?= site_url('about') ?>" class="btn btn-primary me-3">Learn More About Us</a>
                        <a href="<?= site_url('contact') ?>" class="btn btn-outline-primary">Contact Us</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <img src="<?= base_url('assets/images/logo.png') ?>" class="img-fluid"
                        alt="Shri Pramhans Cutting Stone Industries Logo">
                </div>
            </div>
        </div>
    </section>

    <!-- Why Choose Us -->
    <section class="why-choose-us section-padding bg-light" style="background-color: #f9f9f9;">
        <div class="container">
            <div class="section-title text-center">
                <h2>Why Choose Shri Pramhans Cutting Stone Industries</h2>
                <p class="lead">Quality craftsmanship, reliable service, and timeless stone artistry</p>
            </div>

            <div class="row g-4 mt-4">
                <!-- Point 1 -->
                <div class="col-md-6 col-lg-4">
                    <div class="choose-card text-center p-4 h-100">
                        <div class="choose-icon mb-3">
                            <i class="fas fa-gem"></i>
                        </div>
                        <h5>Premium Quality Stone</h5>
                        <p>
                            We use carefully selected natural stone sourced from trusted quarries,
                            ensuring durability, fine finish, and long-lasting beauty.
                        </p>
                    </div>
                </div>

                <!-- Point 2 -->
                <div class="col-md-6 col-lg-4">
                    <div class="choose-card text-center p-4 h-100">
                        <div class="choose-icon mb-3">
                            <i class="fas fa-hammer"></i>
                        </div>
                        <h5>Skilled Craftsmanship</h5>
                        <p>
                            Our experienced artisans specialize in traditional and modern stone
                            carving techniques with attention to every detail.
                        </p>
                    </div>
                </div>

                <!-- Point 3 -->
                <div class="col-md-6 col-lg-4">
                    <div class="choose-card text-center p-4 h-100">
                        <div class="choose-icon mb-3">
                            <i class="fas fa-cogs"></i>
                        </div>
                        <h5>Modern Machinery</h5>
                        <p>
                            We combine advanced machinery with hand craftsmanship to deliver
                            precise cuts, smooth finishes, and consistent quality.
                        </p>
                    </div>
                </div>

                <!-- Point 4 -->
                <div class="col-md-6 col-lg-4">
                    <div class="choose-card text-center p-4 h-100">
                        <div class="choose-icon mb-3">
                            <i class="fas fa-truck"></i>
                        </div>
                        <h5>On-Time Delivery</h5>
                        <p>
                            We understand project timelines and ensure safe packaging and
                            timely delivery across India.
                        </p>
                    </div>
                </div>

                <!-- Point 5 -->
                <div class="col-md-6 col-lg-4">
                    <div class="choose-card text-center p-4 h-100">
                        <div class="choose-icon mb-3">
                            <i class="fas fa-pencil-ruler"></i>
                        </div>
                        <h5>Custom Design Solutions</h5>
                        <p>
                            From temples to modern interiors, we offer customized stone products
                            tailored to your design and size requirements.
                        </p>
                    </div>
                </div>

                <!-- Point 6 -->
                <div class="col-md-6 col-lg-4">
                    <div class="choose-card text-center p-4 h-100">
                        <div class="choose-icon mb-3">
                            <i class="fas fa-handshake"></i>
                        </div>
                        <h5>Trusted & Transparent</h5>
                        <p>
                            Fair pricing, honest communication, and customer satisfaction
                            are at the core of our business values.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="testimonial-section">
        <div class="container">
            <div class="section-title text-center">
                <h2>Client Testimonials</h2>
                <p class="lead mt-3">What our clients say about our work</p>
            </div>

            <div class="testimonial-slider">
                <div class="testimonial-card">
                    <div class="testimonial-text">
                        The sandstone jali work for our temple project was executed with precision and craftsmanship.
                        The attention to detail is remarkable.
                    </div>
                    <div class="testimonial-author">
                        <div class="author-img">
                            <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
                                alt="Client" loading="lazy">
                        </div>
                        <div class="author-info">
                            <h5>Jagrup Talniya</h5>
                            <p>Temple Trust, Jaipur</p>
                        </div>
                    </div>
                </div>

                <div class="testimonial-card">
                    <div class="testimonial-text">
                        The marble carvings for our hotel lobby were delivered on time and exceeded our expectations.
                        The quality is exceptional.
                    </div>
                    <div class="testimonial-author">
                        <div class="author-img">
                            <img src="https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
                                alt="Client" loading="lazy">
                        </div>
                        <div class="author-info">
                            <h5>Priya Verma</h5>
                            <p>Hotel Grand, Udaipur</p>
                        </div>
                    </div>
                </div>

                <div class="testimonial-card">
                    <div class="testimonial-text">
                        Custom stone work for our resort was perfectly executed. The team understood our vision and
                        delivered beyond expectations.
                    </div>
                    <div class="testimonial-author">
                        <div class="author-img">
                            <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
                                alt="Client" loading="lazy">
                        </div>
                        <div class="author-info">
                            <h5>Amit Patel</h5>
                            <p>Resort Owner, Goa</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Quote Modal -->
        <div class="modal fade" id="quoteModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <form action="<?= site_url('quote/request') ?>" method="post">
                        <?= csrf_field() ?>

                        <div class="modal-header">
                            <h5 class="modal-title">Request a Quote</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>

                        <div class="modal-body">
                            <!-- Mobile -->
                            <div class="mb-3">
                                <label class="form-label">Mobile Number</label>
                                <input type="tel" name="mobile" class="form-control" required>
                            </div>

                            <!-- Product ID (hidden) -->
                            <input type="hidden" name="product_id" id="modalProductId">

                            <!-- Source -->
                            <input type="hidden" name="source" value="Home Page">
                        </div>

                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary w-100">
                                Submit Request
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>


    <!-- Footer Section -->
    <?= $this->include('templates/footer') ?>

    <script>
document.addEventListener('DOMContentLoaded', function () {
    var quoteModal = document.getElementById('quoteModal');

    quoteModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget; // clicked button
        var productId = button.getAttribute('data-product-id');

        // hidden input me product id set karo
        quoteModal.querySelector('#modalProductId').value = productId;
    });
});


setTimeout(() => {
    let alert = document.querySelector('.alert');
    if (alert) {
        alert.classList.remove('show');
        alert.classList.add('fade');
    }
}, 3000);
</script>
