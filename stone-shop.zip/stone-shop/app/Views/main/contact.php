<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Contact Shri Pramhans Cutting Stone Industries | Stone Manufacturer in Dausa Rajasthan</title>
    <link rel="shortcut icon" href="assets/images/logo.png" type="image/x-icon">

    <meta name="description"
        content="Contact Shri Pramhans Cutting Stone Industries, a trusted stone manufacturer in Dausa, Rajasthan. Call us or send an enquiry for marble carving, sandstone and custom stone products.">

    <meta name="keywords"
        content="contact stone manufacturer rajasthan, stone supplier dausa, marble carving manufacturer contact, sandstone supplier india">

    <meta name="author" content="Shri Pramhans Cutting Stone Industries">
    <meta name="robots" content="index, follow">

    <link rel="canonical" href="https://shripramhansstones.com/contact.html">

    <!-- Open Graph -->
    <meta property="og:title" content="Contact Shri Pramhans Cutting Stone Industries">
    <meta property="og:description"
        content="Get in touch with Shri Pramhans Cutting Stone Industries for premium stone products and custom stone solutions.">
    <meta property="og:url" content="https://shripramhansstones.com/contact.html">
    <meta property="og:type" content="website">
    <meta property="og:image" content="https://shripramhansstones.com/assets/images/logo.png">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Roboto+Slab:wght@300;400;500;600&display=swap"
        rel="stylesheet">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/styles.css">


    <!-- LocalBusiness Schema -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Shri Pramhans Cutting Stone Industries",
      "image": "https://shripramhansstones.com/assets/images/logo.png",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Dausa",
        "addressRegion": "Rajasthan",
        "addressCountry": "IN",
        "streetAddress": "Industrial Area, Dausa"
      },
      "telephone": "+91-8048606757",
      "email": "info@shripramhansstones.com",
      "url": "https://shripramhansstones.com",
      "openingHours": "Mo-Fr 09:00-18:00, Sa 09:00-14:00",
      "priceRange": "$$"
    }
    </script>
</head>

<body>

    <!-- Header Section -->
    <?= view('templates/header') ?>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <h1>Contact Shri Pramhans Cutting Stone Industries</h1>
            <p class="lead mt-2">Get in Touch with Rajasthan's Premier Stone Manufacturer</p>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item active">Contact Us</li>
                </ol>
            </nav>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="contact-section">
        <div class="container">
            <div class="row g-3">
                <!-- Contact Info -->
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Get in Touch</h2>
                    </div>
                    <p class="mb-4">
                        Reach out to us for premium stone products, marble carving, sandstone solutions and custom stone
                        manufacturing. Our team is ready to assist you with your project requirements.
                    </p>


                    <div class="col-lg-12">
                        <div class="contact-form-box">
                            <h3>Send Us an Enquiry</h3>
                            <p class="mb-4">Fill out the form below and our team will get back to you within 24 hours.
                            </p>
                            <!-- Contact / Enquiry Form -->
                            <form id="contactForm" method="POST" action="<?= site_url('contact/send') ?>" novalidate>
                                <div class="row g-3">

                                    <!-- Name -->
                                    <div class="col-md-6">
                                        <label class="form-label">Your Name *</label>
                                        <input type="text" name="name" id="name" class="form-control" required>
                                        <div class="invalid-feedback">Please enter your name.</div>
                                    </div>

                                    <!-- Phone -->
                                    <div class="col-md-6">
                                        <label class="form-label">Phone Number *</label>
                                        <input type="tel" name="phone" id="phone" class="form-control" required>
                                        <div class="invalid-feedback">Please enter a valid phone number.</div>
                                    </div>

                                    <!-- Email -->
                                    <div class="col-12">
                                        <label class="form-label">Email Address *</label>
                                        <input type="email" name="email" id="email" class="form-control" required>
                                        <div class="invalid-feedback">Please enter a valid email address.</div>
                                    </div>

                                    <!-- Subject -->
                                    <div class="col-12">
                                        <label class="form-label">Subject</label>
                                        <input type="text" name="subject" id="subject" class="form-control">
                                    </div>

                                    <!-- Product Interest -->
                                    <div class="col-12">
                                        <label class="form-label">Product Interest</label>
                                        <select name="product_interest" id="product_interest" class="form-control">
                                            <option value="">Select Product Interest</option>
                                            <option value="sandstone">Sandstone</option>
                                            <option value="marble">Marble</option>
                                            <option value="granite">Granite</option>
                                            <option value="custom-carving">Custom Carving</option>
                                            <option value="stone-jali">Stone Jali Designs</option>
                                            <option value="wall-cladding">Wall Cladding</option>
                                            <option value="other">Other</option>
                                        </select>
                                    </div>

                                    <!-- Message -->
                                    <div class="col-12">
                                        <label class="form-label">Your Requirements *</label>
                                        <textarea name="message" id="message" class="form-control" rows="5"
                                            placeholder="Stone type, quantity, location, project details..."
                                            required></textarea>
                                        <div class="invalid-feedback">Please enter your requirements.</div>
                                    </div>

                                    <!-- Newsletter -->
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="newsletter"
                                                id="newsletter" value="1">
                                            <label class="form-check-label" for="newsletter">
                                                Subscribe to our newsletter
                                            </label>
                                        </div>
                                    </div>

                                    <!-- Submit -->
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-paper-plane me-2"></i> Send Enquiry
                                        </button>
                                    </div>

                                    <!-- Message Area -->
                                    <div class="col-12">
                                        <div id="formMessage"></div>
                                    </div>

                                </div>
                            </form>


                        </div>
                    </div>
                </div>

                <!-- Business Hours -->
                <div class="business-hours">
                    <h5>Business Hours</h5>
                    <p><span class="day">Monday - Friday:</span> <span class="time">9:00 AM - 6:00 PM</span></p>
                    <p><span class="day">Saturday:</span> <span class="time">9:00 AM - 2:00 PM</span></p>
                    <p><span class="day">Sunday:</span> <span class="time">Closed</span></p>
                </div>

                <!-- Google Map -->
                <div class="map-box">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3562.7895123900726!2d76.33249831504324!3d26.738738083203934!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396c9f4d4d8e5f9b%3A0xcf1d4e5c9c8b3b3c!2sDausa%2C%20Rajasthan%2C%20India!5e0!3m2!1sen!2sus!4v1629876543210!5m2!1sen!2sus"
                        width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"
                        title="Location of Shri Pramhans Cutting Stone Industries in Dausa, Rajasthan">
                    </iframe>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const contactForm = document.getElementById('contactForm');
            const formMessage = document.getElementById('formMessage');

            if (!contactForm) return;

            contactForm.addEventListener('submit', function (e) {
                e.preventDefault();

                const name = document.getElementById('name');
                const phone = document.getElementById('phone');
                const email = document.getElementById('email');
                const message = document.getElementById('message');

                let valid = true;

                // Reset validation
                [name, phone, email, message].forEach(field => {
                    field.classList.remove('is-invalid');
                });

                if (!name.value.trim()) {
                    name.classList.add('is-invalid');
                    valid = false;
                }

                if (!phone.value.trim()) {
                    phone.classList.add('is-invalid');
                    valid = false;
                }

                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email.value.trim())) {
                    email.classList.add('is-invalid');
                    valid = false;
                }

                if (!message.value.trim()) {
                    message.classList.add('is-invalid');
                    valid = false;
                }

                if (!valid) {
                    showMessage('Please fill all required fields correctly.', 'danger');
                    return;
                }

                // Send form via AJAX to CI4
                const formData = new FormData(contactForm);

                fetch(contactForm.action, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                    .then(res => res.ok ? res.json() : Promise.reject())
                    .then(() => {
                        showMessage(
                            '<i class="fas fa-check-circle me-2"></i> Thank you! Your enquiry has been sent successfully.',
                            'success'
                        );
                        contactForm.reset();
                    })
                    .catch(() => {
                        showMessage('Something went wrong. Please try again later.', 'danger');
                    });
            });

            function showMessage(message, type) {
                formMessage.innerHTML = `<div class="alert alert-${type} mt-3">${message}</div>`;
                formMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        });
    </script>

    <?= view('templates/footer') ?>