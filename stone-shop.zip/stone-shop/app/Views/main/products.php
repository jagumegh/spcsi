<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stone Products | Marble, Sandstone, Stone Jali Manufacturer - Shri Pramhans</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Roboto+Slab:wght@300;400;500;600&display=swap"
        rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/styles.css">

    <meta name="description"
        content="Explore our premium stone products including marble statues, sandstone murals, stone jali designs, and more. Manufactured by Shri Pramhans Cutting Stone Industries.">
    <meta name="keywords"
        content="Stone Products, Marble Products, Sandstone Products, Stone Jali, Wall Murals, Stone Sculptures, Stone Manufacturer, Shri Pramhans Cutting Stone Industries">
    <meta name="author" content="Shri Pramhans Cutting Stone Industries">

    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="Stone Products | Marble, Sandstone, Stone Jali Manufacturer - Shri Pramhans">
    <meta property="og:description"
        content="Explore our premium stone products including marble statues, sandstone murals, stone jali designs, and more. Manufactured by Shri Pramhans Cutting Stone Industries.">
    <meta property="og:url" content="https://shripramhansstones.com/products.html">
    <meta property="og:site_name" content="Shri Pramhans Cutting Stone Industries">
    <meta property="og:type" content="website">
    <meta property="og:image" content="https://shripramhansstones.com/assets/images/logo.png">

</head>

<body>
    <!-- Header Section -->
    <?= view('templates/header') ?>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <h1>Stone Products Collection</h1>
            <p class="lead mt-2">Manufacturer of Premium Quality Marble, Sandstone & Natural Stone Products</p>

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item active">Products</li>
                </ol>
            </nav>
        </div>
    </section>

    <!-- Product Filter -->
    <div class="container">
        <div class="product-filter">
            <div class="row align-items-center">
                <div class="col-lg-8 mb-3 mb-lg-0">
                    <div class="filter-buttons">
                        <button class="filter-btn active" data-filter="all">All Products</button>
                        <button class="filter-btn" data-filter="marble">Marble</button>
                        <button class="filter-btn" data-filter="sandstone">Sandstone</button>
                        <button class="filter-btn" data-filter="jali">Stone Jali</button>
                        <button class="filter-btn" data-filter="wall-murals">Wall Murals</button>
                        <button class="filter-btn" data-filter="sculpture">Sculpture</button>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="search-box">
                        <input type="text" id="productSearch" placeholder="Search products by name...">
                        <button type="button" id="searchBtn">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
            <?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
        <strong>✔</strong> <?= session()->getFlashdata('success') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>
    <!-- Products Grid -->
    <section class="products-section">
        <div class="container">
            <div class="row">

                <?php if (! empty($products)) : ?>
                <?php foreach ($products as $product) : ?>

                <div class="col-6 col-sm-4 col-md-4 col-lg-3 mb-4 product-item"
                    data-category="<?= esc(strtolower($product['category_slug'])) ?>">

                    <div class="product-card">

                        <div class="product-image">
                            <img src="<?= !empty($product['image_url'])
                            ? base_url('assets/images/' . esc($product['image_url']))
                            : base_url('assets/images/pro2.jpg') ?>" alt="<?= esc($product['name']) ?>">
                        </div>

                        <div class="product-info">

                            <div class="product-category">
                                <?= esc(strtoupper($product['category_name'])) ?>
                            </div>

                            <h3 class="product-title">
                                <a href="<?= site_url('product/' . esc($product['slug'])) ?>">
                                    <?= esc($product['name']) ?>
                                </a>
                            </h3>

                            <p class="product-description">
                                <?= esc($product['short_description']) ?>
                            </p>

                            <div class="product-price">
                                ₹
                                <?= esc($product['price']) ?>
                            </div>

                            <div class="product-meta">
                                <div class="product-actions d-flex gap-2">

                                    <a href="<?= site_url('product/' . esc($product['slug'])) ?>"
                                        class="btn btn-sm btn-view">
                                        View Details
                                    </a>

                                    <a href="#" class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#quoteModal" data-product-id="<?= esc($product['id']) ?>">
                                        Send Enquiry
                                    </a>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <?php endforeach; ?>
                <?php else : ?>
                <p class="text-center">No products found.</p>
                <?php endif; ?>

            </div>
            <!-- Pagination -->
            <div class="pagination-container">
                <nav aria-label="Page navigation">
                    <ul class="pagination">
                        <li class="page-item disabled">
                            <a class="page-link" href="#">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        </li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </section>

    <!-- Product Details Section -->
    <section class="categories-section" style="background: #f9f9f9;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mb-4 mb-lg-0">
                    <div class="product-details-box">
                        <h3>Product Specifications</h3>
                        <div class="spec-item">
                            <div class="spec-label">Material</div>
                            <div class="spec-value">Natural Marble/Sandstone/Granite</div>
                        </div>
                        <div class="spec-item">
                            <div class="spec-label">Color</div>
                            <div class="spec-value">White, Beige, Red, Yellow, Natural</div>
                        </div>
                        <div class="spec-item">
                            <div class="spec-label">Finish</div>
                            <div class="spec-value">Polished, Honed, Natural, Rough</div>
                        </div>
                        <div class="spec-item">
                            <div class="spec-label">Thickness</div>
                            <div class="spec-value">20mm to 50mm (Customizable)</div>
                        </div>
                        <div class="spec-item">
                            <div class="spec-label">Usage</div>
                            <div class="spec-value">Temple, Home, Hotel, Garden, Commercial</div>
                        </div>
                        <div class="spec-item">
                            <div class="spec-label">Customization</div>
                            <div class="spec-value">Available as per design requirements</div>
                        </div>
                        <div class="spec-item">
                            <div class="spec-label">Payment Terms</div>
                            <div class="spec-value">Cash, Cheque, Online Transfer</div>
                        </div>
                        <div class="spec-item">
                            <div class="spec-label">Delivery Time</div>
                            <div class="spec-value">7-15 days (Depending on order size)</div>
                        </div>
                        <div class="spec-item">
                            <div class="spec-label">Packaging</div>
                            <div class="spec-value">Wooden Crate & Bubble Wrap</div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="contact-seller-box">
                        <div class="seller-info">
                            <div class="seller-name">Shri Pramhans Stone</div>
                            <div class="seller-rating">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star-half-alt"></i>
                                <span class="ms-1">(4.5)</span>
                            </div>
                            <p class="text-muted small">Stone Manufacturer since 2024</p>
                        </div>

                        <div class="contact-actions">
                            <a href="tel:08048606757" class="btn-contact">
                                <i class="fas fa-phone-alt me-2"></i> Call Now: 08048606757
                            </a>
                            <a href="https://wa.me/918048606757" target="_blank" class="btn-contact btn-whatsapp">
                                <i class="fab fa-whatsapp me-2"></i> WhatsApp Inquiry
                            </a>
                            <a href="quote.html" class="btn-contact" style="background: #28a745;">
                                <i class="fas fa-file-alt me-2"></i> Get Free Quote
                            </a>
                            <a href="contact.html" class="btn-contact" style="background: #17a2b8;">
                                <i class="fas fa-envelope me-2"></i> Send Email
                            </a>
                        </div>

                        <div class="mt-4">
                            <p class="small text-muted mb-2">
                                <i class="fas fa-check-circle text-success me-1"></i>
                                Verified Supplier
                            </p>
                            <p class="small text-muted mb-2">
                                <i class="fas fa-check-circle text-success me-1"></i>
                                GST Registered
                            </p>
                            <p class="small text-muted">
                                <i class="fas fa-check-circle text-success me-1"></i>
                                MSME Registered
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Get Quote Modal -->

    <div class="modal fade" id="quoteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form action="<?= site_url('quote/request') ?>" method="post">
                    <?= csrf_field() ?>

                    <div class="modal-header">
                        <h5 class="modal-title">Request a Quote</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">
                        <!-- Mobile -->
                        <div class="mb-3">
                            <label class="form-label">Mobile Number</label>
                            <input type="tel" name="mobile" class="form-control" required>
                        </div>

                        <!-- Product ID (hidden) -->
                        <input type="hidden" name="product_id" id="modalProductId">

                        <!-- Source -->
                        <input type="hidden" name="source" value="Home Page">
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary w-100">
                            Submit Request
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?= view('templates/footer') ?>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var quoteModal = document.getElementById('quoteModal');

            quoteModal.addEventListener('show.bs.modal', function (event) {
                var button = event.relatedTarget;
                var productId = button.getAttribute('data-product-id');

                quoteModal.querySelector('#modalProductId').value = productId;
            });
        });


        setTimeout(() => {
            let alert = document.querySelector('.alert');
            if (alert) {
                alert.classList.remove('show');
                alert.classList.add('fade');
            }
        }, 3000);
    </script>