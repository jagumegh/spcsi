<!DOCTYPE html>
<html lang="en">

<head>
    <!-- 1️⃣ Page Head (Basic Setup) -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marble Sitting Buddha Statue | Product Details | Handcrafted Marble Art</title>
    <meta name="description"
        content="Premium white marble Sitting Buddha statue, handcrafted by skilled artisans in Rajasthan. 18-inch polished marble statue perfect for meditation spaces, gardens, or home decor. Custom sizes available.">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="shortcut icon" href="<?= base_url('assets/images/favicon.png') ?>" type="image/x-icon">

    <!-- Font Awesome Icons -->
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Roboto+Slab:wght@300;400;500;600&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <link rel="stylesheet" href="<?= base_url('assets/css/styles.css') ?>">

    <!-- Custom CSS -->
    <style>
        /* Product Images */
    </style>
</head>

<body>

    <!-- Header Section -->
    <?= view('templates/header') ?>

    <!-- 2️⃣ Breadcrumb / Page Header -->
    <div class="page-header">
        <div class="container">
            <h1>Marble Sitting Buddha Statue</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html"> Home</a></li>
                    <li class="breadcrumb-item"><a href="products.html">Products</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Marble Buddha Statue</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="container">
        <!-- 3️⃣ Product Main Section -->
        <div class="row mb-5">
            <!-- Left Side: Product Images -->
            <div class="col-lg-6">
                <div class="main-product-image">
                    <img id="mainImage"
                        src="https://images.unsplash.com/photo-1548013146-72479768bada?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
                        alt="Marble Sitting Buddha Statue - Front View" class="img-fluid">
                </div>
                <div class="thumbnail-images">
                    <div class="thumbnail active"
                        onclick="changeImage('https://images.unsplash.com/photo-1548013146-72479768bada?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80')">
                        <img src="https://images.unsplash.com/photo-1548013146-72479768bada?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
                            alt="Marble Buddha Front" class="img-fluid">
                    </div>

                    <div class="thumbnail"
                        onclick="changeImage('https://images.unsplash.com/photo-1548013146-72479768bada?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80&facepad=3')">
                        <img src="https://images.unsplash.com/photo-1548013146-72479768bada?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80&facepad=3"
                            alt="Marble Buddha Close-up" class="img-fluid">
                    </div>
                    <div class="thumbnail"
                        onclick="changeImage('https://images.unsplash.com/photo-1580584126903-c17d41830450?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80')">
                        <img src="https://images.unsplash.com/photo-1580584126903-c17d41830450?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80"
                            alt="Marble Buddha in Garden" class="img-fluid">
                    </div>
                </div>
            </div>

            <!-- Right Side: Product Info -->
            <div class="col-lg-6">
                <div class="product-category">Marble Statues</div>
                <h2 class="product-title">Handcrafted Marble Sitting Buddha Statue</h2>
                <div class="product-price">₹9,000 - ₹15,000</div>

                <p class="lead">A beautifully handcrafted white marble Buddha statue in a meditative sitting pose,
                    perfect for creating a peaceful atmosphere in your home or garden.</p>

                <div class="mb-4">
                    <p><strong>Availability:</strong> <span class="availability in-stock"><i
                                class="fas fa-check-circle"></i> In Stock</span> (Standard size) | <span
                            class="availability made-to-order"><i class="fas fa-clock"></i> Made to Order</span> (Custom
                        sizes)</p>
                    <p><strong>Delivery:</strong> 5-7 business days (In stock) | 15-20 days (Made to order)</p>
                </div>

                <!-- 5️⃣ Call-to-Action Buttons -->
                <div class="cta-buttons mb-5">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#quoteModal">
                        <i class="fas fa-envelope"></i> Enquiry Now
                    </button>
                    <a href="https://wa.me/919876543210?text=Hi,%20I'm%20interested%20in%20the%20Marble%20Sitting%20Buddha%20Statue"
                        class="btn btn-whatsapp" target="_blank">
                        <i class="fab fa-whatsapp"></i> WhatsApp
                    </a>
                    <a href="tel:+919876543210" class="btn btn-call">
                        <i class="fas fa-phone"></i> Call Now
                    </a>
                </div>
            </div>

            <!-- Specifications + Description -->
            <div class="row mb-5">

                <!-- Left: Product Specifications -->
                <div class="col-12 col-md-6">
                    <h4 class="section-title">Product Specifications</h4>
                    <table class="specifications-table">
                        <tr>
                            <th>Material</th>
                            <td>Premium White Makrana Marble</td>
                        </tr>
                        <tr>
                            <th>Height</th>
                            <td>18 Inches (Standard) | Custom sizes available</td>
                        </tr>
                        <tr>
                            <th>Weight</th>
                            <td>12 kg (Approximately)</td>
                        </tr>
                        <tr>
                            <th>Finish</th>
                            <td>Hand Polished to High Gloss</td>
                        </tr>
                        <tr>
                            <th>Usage</th>
                            <td>Indoor & Outdoor (Weather Resistant)</td>
                        </tr>
                        <tr>
                            <th>Origin</th>
                            <td>Handcrafted in Rajasthan, India</td>
                        </tr>
                        <tr>
                            <th>Care Instructions</th>
                            <td>Wipe with soft cloth, avoid harsh chemicals</td>
                        </tr>
                    </table>
                </div>

                <!-- Right: Product Description -->
                <div class="col-12 col-md-6">
                    <h4 class="section-title">Product Description</h4>
                    <p>
                        This exquisite Marble Sitting Buddha Statue is meticulously handcrafted by skilled artisans
                        from Rajasthan, India, using traditional techniques passed down through generations.
                    </p>
                    <p>
                        Carved from premium quality white Makrana marble (the same marble used in the Taj Mahal),
                        this statue features exceptional detail in the facial expression, robe folds, and hand
                        positioning.
                    </p>
                </div>

            </div>
            <!-- Why Choose This Product -->
            <div class="row mb-5">
                <div class="col-12">
                    <h4 class="section-title">Why Choose This Buddha Statue?</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <ul class="why-choose-list">
                                <li>Handcrafted by skilled artisans with 20+ years experience</li>
                                <li>Premium quality marble that lasts for generations</li>
                                <li>Long-lasting & weather resistant</li>
                                <li>Natural marble with unique veining</li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <ul class="why-choose-list">
                                <li>Custom sizes available</li>
                                <li>Ethically sourced materials</li>
                                <li>Perfect for home, office, or garden</li>
                                <li>Creates a peaceful atmosphere</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Get Quote Modal -->
    <div class="modal fade" id="quoteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">Get a Quote</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <form id="quoteForm">
                        <div class="mb-3">
                            <label class="form-label">Mobile Number</label>
                            <input type="tel" class="form-control" placeholder="Enter your mobile number"
                                pattern="[0-9]{10}" required>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">
                            Submit
                        </button>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- Footer Section -->
    <?= view('templates/footer') ?>