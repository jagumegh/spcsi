<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/about', 'Home::about');
$routes->get('/contact', 'Home::contact');
$routes->get('/products', 'Home::products');
$routes->get('/gallery', 'Home::gallery');
$routes->get('/product-details', 'Home::productDetails');
$routes->post('contact/send', 'Home::sendContact');
$routes->post('quote/request', 'Home::request');