<?php

namespace App\Controllers;

error_reporting(E_ALL);
ini_set('display_errors', 1);

use App\Models\SliderModel;
use App\Models\ProductModel;
use App\Models\GalleryModel;
use App\Models\EnquiryModel;
use App\Models\QuoteModel;

class Home extends BaseController
{
    public function index()
    {
    // Slider
    $sliderModel = new SliderModel();
    $data['sliders'] = $sliderModel
        ->orderBy('id', 'ASC')
        ->findAll();

    // Products with main image
    $productModel = new ProductModel();
    $data['products'] = $productModel
        ->select('products.*, product_images.image_url')
        ->join(
            'product_images',
            'product_images.product_id = products.id AND product_images.is_main = 1',
            'left'
        )
        ->where('products.is_active', 1)
        ->orderBy('products.id', 'DESC')
        ->findAll();

    return view('main/index', $data);
    }
    public function about()
    {
        return view('main/about');
    }

    public function contact()
    {
        return view('main/contact');
    }

    public function sendContact()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(403);
        }

        $enquiryModel = new EnquiryModel();

        $data = [
            'name'             => $this->request->getPost('name'),
            'phone'            => $this->request->getPost('phone'),
            'email'            => $this->request->getPost('email'),
            'subject'          => $this->request->getPost('subject'),
            'product_interest' => $this->request->getPost('product_interest'),
            'message'          => $this->request->getPost('message'),
            'newsletter'       => $this->request->getPost('newsletter') ? 1 : 0,
            'ip_address'       => $this->request->getIPAddress(),
        ];

        $enquiryModel->insert($data);

        return $this->response->setJSON([
            'status'  => 'success',
            'message' => 'Enquiry sent successfully!'
        ]);
    }


    public function products()
    {
        return view('main/products');
    }
    public function gallery()
    {
        $galleryModel = new GalleryModel();
        $data['gallery'] = $galleryModel
        ->where('is_active', 1)
        ->orderBy('id', 'DESC')
        ->findAll();

        return view('main/gallery', $data);
    }

    public function productDetails()
    {
        return view('main/product_details');
    }

 public function request()
    {
        $quoteModel = new QuoteModel();

        $data = [
            'mobile'       => $this->request->getPost('mobile'),
            'product_id'   => $this->request->getPost('product_id'),
            'source'       => $this->request->getPost('source'),
            'ip_address'   => $this->request->getIPAddress(),
            'is_contacted' => 0,
        ];

        $quoteModel->insert($data);

        return redirect()->back()->with('success', 'Quote request submitted successfully!');
    }



}
